export const environment = {
  production: true,

  serviceUrl: "https://prime-games-api.azurewebsites.net/api",
  imageUrl: "https://prime-games-api.azurewebsites.net",
};
