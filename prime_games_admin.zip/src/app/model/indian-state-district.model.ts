
export class State {
    state: string;
    districts: string[]
} 

export class IndianStateDistrict {
    states: State[] 
}
