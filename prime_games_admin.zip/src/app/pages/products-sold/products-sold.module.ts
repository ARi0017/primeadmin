import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProductsSoldRoutingModule } from './products-sold-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    ProductsSoldRoutingModule
  ]
})
export class ProductsSoldModule { }
